// ---------- 1. Os dados: a lista de fotos ----------
const fotos = [
  { arquivo: "IMG/jardim-botanico.jpg",       titulo: "Jardim Botânico",      categoria: "parques" },
  { arquivo: "IMG/parque-tangua.jpg",         titulo: "Parque Tanguá",        categoria: "parques" },
  { arquivo: "IMG/opera-de-arame.jpg",        titulo: "Ópera de Arame",       categoria: "arquitetura" },
  { arquivo: "IMG/museu-oscar-niemeyer.jpg",  titulo: "Museu Oscar Niemeyer", categoria: "arquitetura" },
  { arquivo: "IMG/torre-panoramica.jpg",      titulo: "Torre Panorâmica",     categoria: "cidade" },
  { arquivo: "IMG/rua-xv.jpg",                titulo: "Rua XV de Novembro",   categoria: "cidade" }
];

// ---------- 2. Pegando os elementos da página ----------
const grade       = document.getElementById("grade");
const filtros     = document.querySelectorAll(".filtro");
const lightbox    = document.getElementById("lightbox");
const lbImagem    = document.getElementById("lbImagem");
const lbLegenda   = document.getElementById("lbLegenda");
const btnFechar   = document.getElementById("lbFechar");
const btnAnterior = document.getElementById("lbAnterior");
const btnProxima  = document.getElementById("lbProxima");
const botaoMenu   = document.getElementById("botaoMenu");
const menuTopo    = document.getElementById("menuTopo");

// ---------- 3. Variáveis de controle ----------
let visiveis = fotos;  // as fotos que estão aparecendo agora
let atual = 0;         // posição da foto aberta no lightbox

// ---------- 4. Desenhar as fotos na grade ----------
function mostrarFotos(categoria) {
  if (categoria === "todas") {
    visiveis = fotos;
  } else {
    visiveis = fotos.filter(function (foto) {
      return foto.categoria === categoria;
    });
  }

  grade.innerHTML = "";

  visiveis.forEach(function (foto, indice) {
    const botao = document.createElement("button");
    botao.className = "foto";
    botao.type = "button";

    const img = document.createElement("img");
    img.src = foto.arquivo;
    img.alt = foto.titulo;
    img.loading = "lazy";

    const legenda = document.createElement("span");
    legenda.textContent = foto.titulo;

    botao.append(img, legenda);
    botao.addEventListener("click", function () {
      abrirLightbox(indice);
    });

    grade.appendChild(botao);
  });
}

// ---------- 5. Filtros ----------
filtros.forEach(function (botao) {
  botao.addEventListener("click", function () {
    filtros.forEach(function (b) {
      b.classList.remove("ativo");
    });
    botao.classList.add("ativo");
    mostrarFotos(botao.dataset.categoria);
  });
});

// ---------- 6. Lightbox (foto ampliada) ----------
function atualizarLightbox() {
  const foto = visiveis[atual];
  lbImagem.src = foto.arquivo;
  lbImagem.alt = foto.titulo;
  lbLegenda.textContent = foto.titulo + " (" + (atual + 1) + " de " + visiveis.length + ")";
}

function abrirLightbox(indice) {
  atual = indice;
  atualizarLightbox();
  lightbox.classList.add("aberto");
  document.body.classList.add("sem-rolagem");
  btnFechar.focus();
}

function fecharLightbox() {
  lightbox.classList.remove("aberto");
  document.body.classList.remove("sem-rolagem");
}

function proximaFoto() {
  atual = (atual + 1) % visiveis.length;
  atualizarLightbox();
}

function fotoAnterior() {
  atual = (atual - 1 + visiveis.length) % visiveis.length;
  atualizarLightbox();
}

btnFechar.addEventListener("click", fecharLightbox);
btnProxima.addEventListener("click", proximaFoto);
btnAnterior.addEventListener("click", fotoAnterior);

// clicar no fundo escuro (fora da foto) também fecha
lightbox.addEventListener("click", function (evento) {
  if (evento.target === lightbox) {
    fecharLightbox();
  }
});

// teclado: Esc fecha, setas navegam
document.addEventListener("keydown", function (evento) {
  if (!lightbox.classList.contains("aberto")) {
    return;
  }
  if (evento.key === "Escape")     fecharLightbox();
  if (evento.key === "ArrowRight") proximaFoto();
  if (evento.key === "ArrowLeft")  fotoAnterior();
});

// ---------- 7. Menu do celular ----------
botaoMenu.addEventListener("click", function () {
  const aberto = menuTopo.classList.toggle("aberto");
  botaoMenu.setAttribute("aria-expanded", aberto);
});

// ---------- 8. Começar mostrando todas as fotos ----------
mostrarFotos("todas");