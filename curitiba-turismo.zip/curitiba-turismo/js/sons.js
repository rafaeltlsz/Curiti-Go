document.addEventListener("DOMContentLoaded", function () {
    const audioHino = document.getElementById("audio-hino");
    const statusAudio = document.getElementById("status");
    const botao = document.getElementById("btn-tocar");
    const audioElements = document.querySelectorAll("audio");

    audioHino.addEventListener("play", () => {
        statusAudio.textContent = "Tocando: Hino de Curitiba";
        botao.textContent = "Pausar Hino de Curitiba";
    });

    audioHino.addEventListener("pause", () => {
        statusAudio.textContent = "Hino de Curitiba pausado";
        botao.textContent = "Tocar Hino de Curitiba";
    });

    botao.addEventListener("click", () => {
        if (audioHino.paused) {
            audioHino.play();
        } else {
            audioHino.pause();
        }
    });

    audioElements.forEach(audio => {
        audio.addEventListener("play", () => {
            audioElements.forEach(outroAudio => {
                if (outroAudio !== audio) {
                    outroAudio.pause();
                }
            });
        });
    });
});
