document.addEventListener("DOMContentLoaded", function () {
    const menuToggle = document.getElementById("menu-toggle");
    const menuPrincipal = document.getElementById("menu-principal");

    if (menuToggle && menuPrincipal) {
        menuToggle.addEventListener("click", function () {
            menuPrincipal.classList.toggle("aberto");
        });
    }
});